import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet, IonHeader, IonToolbar, IonContent, IonTitle, IonButton, IonImg, IonItem } from '@ionic/angular/standalone';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Share } from '@capacitor/share';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [IonApp, IonRouterOutlet, IonHeader, IonToolbar, IonContent, IonTitle, IonButton, IonImg, IonItem],
})
export class AppComponent {
  readyForSelfie:boolean = false;
  selfieTaken:boolean = false;
  photo:Photo|undefined = undefined;
  
  constructor() {}

  async scheduleSelfie() {
    await LocalNotifications.requestPermissions();
    LocalNotifications.addListener("localNotificationReceived", (notification) => {
      this.readyForSelfie = true;
    });
    let delay = new Date();
    delay.setSeconds(delay.getSeconds() + 10);
   var notification = await LocalNotifications.schedule({
     notifications: [
       {
         title: 'Daily Selfie Reminder',
         body: 'Time to take a selfie!',
         id: 1,
         schedule: { at: delay },
       },
     ],
   });
 }

 async takeSelfie() {
   this.photo = await Camera.getPhoto({
     resultType: CameraResultType.Uri,
     source: CameraSource.Camera,
     quality: 100,
   });
   this.selfieTaken = true;
 }

 async shareSelfie() {
  //Can't actually share the file because web support currently doesn't enable it :-(
  Share.share({
    title: 'Share with TAs',
    text: 'Hello from IN4MATX 133 lecture!',
    url: 'http://inf133-wi25.depstein.net/'
  });
 }
}
