import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet, IonHeader, IonToolbar, IonContent, IonTitle, IonButton, IonImg, IonItem } from '@ionic/angular/standalone';
import { CameraResultType, CameraSource } from '@capacitor/camera';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [IonApp, IonRouterOutlet, IonHeader, IonToolbar, IonContent, IonTitle, IonButton, IonImg, IonItem],
})
export class AppComponent {
  readyForSelfie:boolean = false;
  selfieTaken:boolean = false;
  photo:string|null = null;

  constructor() {}

  async scheduleSelfie() {
    //TODO: Use LocalNotifications to request permission to send notifications
    //and schedule a reminder to take a selfie in ~3 seconds
    //You'd ideally want to listen for the notification to be received,
    //but this does not appear to be enabled for web
    this.readyForSelfie = true;
  }

  async takeSelfie() {
    //TODO: Use Camera to take a photo and store it in the photo variable
    this.selfieTaken = true;
  }

  async shareSelfie() {
    //TODO: Use Share to share the photo
    //Unfortunately, we can't share the file because the web plugin is limited :-(
    //but we can send the TAs a text instead :-)
    //informatics-133-staff@uci.edu
  }
}
