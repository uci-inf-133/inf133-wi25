import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideIndexedDb, DBConfig } from 'ngx-indexed-db';

//Configuration for the database: note the store schema, and the id field that auto-increments
const dbConfig: DBConfig  = {
  name: 'db',
  version: 1,
  objectStoresMeta: [{
    store: 'groceries',
    storeConfig: { keyPath: 'id', autoIncrement: true },
    storeSchema: [
      { name: 'name', keypath: 'name', options: { unique: false } },
      { name: 'quantity', keypath: 'quantity', options: { unique: false } }
    ]
  }]
};

import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [provideIndexedDb(dbConfig), provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes)]
};
