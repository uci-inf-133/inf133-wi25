var o=(r,...n)=>console.warn(`[Ionic Warning]: ${r}`,...n);var e=(r,...n)=>console.error(`<${r.tagName.toLowerCase()}> must be used inside ${n.join(" or ")}.`);export{o as a,e as b};
