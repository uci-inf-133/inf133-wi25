import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'solution1';
  website_url = 'https://inf133-wi25.depstein.net/';
  slack_url = 'https://uci-inf-133-wi25.slack.com/';
}
