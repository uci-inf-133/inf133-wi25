import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NgxIndexedDBService } from 'ngx-indexed-db';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  item:string = '';
  quantity:number = 0;

  shopping_list:any[] =  [];

  constructor(private dbService:NgxIndexedDBService) {
    // this.dbService.clear('groceries').subscribe((success) => {
    //   console.log(success);
    // })
    this.loadGroceryList();
  }

  addItem() {
    this.dbService.add('groceries', {'name':this.item, 'quantity': this.quantity}).subscribe((value) => {
      console.log(value);
      this.loadGroceryList();
    });
  }

  loadGroceryList() {
    this.dbService.getAll('groceries').subscribe((groceries) => {
      this.shopping_list = [];
      groceries.forEach((grocery:any) => {
        this.shopping_list.push({'name':grocery['name'], 'quantity':grocery['quantity']});
      })
    });
  }
}
