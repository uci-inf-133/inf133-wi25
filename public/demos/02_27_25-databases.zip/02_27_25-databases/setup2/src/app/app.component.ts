import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NgxIndexedDBService } from 'ngx-indexed-db';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  // Binds to input fields
  item:string = '';
  quantity:number = 0;

  shopping_list:any[] =  [];

  constructor(private dbService:NgxIndexedDBService) {
    //loads whatever is stored in the grocery list
    this.loadGroceryList();
  }

  addItem() {
    //TODO: add item to the database and load the grocery list
  }

  loadGroceryList() {
    //TODO: use getAll to get all groceries from the DB and add them to the shopping list
    //Remember to clear the shopping list in between each call!
  }
}
